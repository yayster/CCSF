#!/bin/sh

. ./quiz2.sh
psnum
memsize
